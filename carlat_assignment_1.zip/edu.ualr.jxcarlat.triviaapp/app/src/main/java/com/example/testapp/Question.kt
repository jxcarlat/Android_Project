package com.example.testapp
//This initializes our Question class, creating all of the variables we need to
//make our myQuestions array in the GuessActivity.
class Question(var questionText: String, var options: Array<String>, var correctIndex: Int) {

}