package com.example.testapp

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class FinalScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final_screen)

        val resultTextView: TextView =
                findViewById(R.id.endResults)
        val scoreScreen: TextView =
                findViewById(R.id.score)

        val playAgain: Button =
                findViewById(R.id.playAgain)
        //When we finish all of our questions we are sent to the FinalScreen. In this screen
        //we show the player his total score by assigning the value to score and displaying
        //it by assigning the value to our scoreScreen text. We also allow our player to
        //have the option of taking the quiz again by letting them go back to the MainActivity.
        val sharedPreferences =
                getSharedPreferences(SHARED_PREFS_FILE, Context.MODE_PRIVATE)
        var score = sharedPreferences.getInt(KEY_SCORE, 0)
        scoreScreen.text = score.toString()

        playAgain.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
